
Nubra Product Intern Assignment – Guided Strategy Builder

1. UX/UI Suggestions
- Wizard-based flow for strategy creation reduces cognitive load.
- Live payoff diagram and Greeks updates as legs are added.
- Interactive sliders for risk/reward scenario simulation.
- Sticky summary panel showing cost, margin, breakeven.
- Accessible design: ARIA labels, keyboard navigation, mobile-friendly layout.

2. Competitor Analysis
Platform       | Strengths                              | Gaps / Limitations
Zerodha Streak | No-code builder, integrated brokerage | Limited historical depth, basic automation
Tradetron      | Cloud deployment, marketplace         | Complexity, higher cost
QuantConnect   | Code-driven, powerful backtesting     | High coding barrier, not India-optimized
Nubra          | Options focus, institutional charts   | Limited paper → real gradual deployment, marketplace

3. Proposed Feature: Guided Strategy Builder + Auto-Pilot Mode
Goal: Help manual traders safely transition to algorithmic trading.
Components:
- Step-by-step wizard (Underlying → Template → Add Legs → Backtest → Deploy)
- Live payoff visualization and cost/margin updates
- Backtester with historical data, slippage, and commission modeling
- Deployment modes: Paper → Fractional → Full
- Monitoring dashboard: open trades, equity curve, pause/stop controls
- Template marketplace for strategy cloning

4. Wireframe Description
- Screenshots included (placeholders in Wireframes/)
- Built using React for a live interactive wireframe.

5. Instructions
- Open React_Wireframe_Project/
- Run: npm install && npm start
- View at http://localhost:3000
