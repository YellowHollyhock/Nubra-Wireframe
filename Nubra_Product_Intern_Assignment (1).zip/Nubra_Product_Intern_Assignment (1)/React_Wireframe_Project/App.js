import React from "react";
import NubraGuidedStrategyBuilderFull from "./NubraGuidedStrategyBuilderFull";

function App() {
  return <NubraGuidedStrategyBuilderFull />;
}

export default App;
