import React, { useState } from "react";

export default function NubraGuidedStrategyBuilderFull() {
  const [step, setStep] = useState(1);

  const nextStep = () => setStep((prev) => Math.min(prev + 1, 4));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));

  const cardStyle = {
    background: "#f5f7fa",
    padding: "20px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.05)",
    marginBottom: "20px",
  };

  const sectionHeader = {
    borderBottom: "2px solid #007bff",
    paddingBottom: "8px",
    marginBottom: "15px",
    color: "#007bff",
  };

  const buttonStyle = {
    background: "#007bff",
    color: "#fff",
    padding: "10px 20px",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    marginRight: "10px",
    marginTop: "10px",
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "30px", background: "#eaeff2" }}>
      {/* Header */}
      <header style={{ marginBottom: "40px", textAlign: "center" }}>
        <h1 style={{ color: "#007bff" }}>Nubra Guided Strategy Builder</h1>
        <p style={{ fontSize: "16px", color: "#555" }}>
          Interactive wizard demo for transitioning manual traders to algo trading
        </p>
      </header>

      {/* Wizard Steps */}
      <section style={cardStyle}>
        <h2 style={sectionHeader}>Step {step}</h2>
        {step === 1 && (
          <div>
            <h3>Choose Underlying</h3>
            <input
              type="text"
              placeholder="Search stock / index"
              style={{ padding: "10px", borderRadius: "8px", border: "1px solid #ccc", width: "100%" }}
            />
          </div>
        )}
        {step === 2 && (
          <div>
            <h3>Add Legs</h3>
            <p>(Buy Call, Sell Put, etc.)</p>
            <textarea
              placeholder="Describe your strategy legs..."
              style={{ width: "100%", height: "80px", borderRadius: "8px", border: "1px solid #ccc", padding: "10px" }}
            />
          </div>
        )}
        {step === 3 && (
          <div>
            <h3>Backtest</h3>
            <ul>
              <li>Paper → Fractional conversion within 30 days: target 12%</li>
              <li>Wizard completion rate: target 45%</li>
              <li>Backtest success and latency: 95% success, median &lt;30s</li>
            </ul>
          </div>
        )}
        {step === 4 && (
          <div>
            <h3>Deploy</h3>
            <p>Choose deployment mode:</p>
            <button style={buttonStyle}>Deploy Paper</button>
            <button style={buttonStyle}>Deploy Full</button>
          </div>
        )}

        {/* Navigation */}
        <div style={{ marginTop: "20px" }}>
          {step > 1 && <button style={buttonStyle} onClick={prevStep}>Previous</button>}
          {step < 4 && <button style={buttonStyle} onClick={nextStep}>Next</button>}
        </div>
      </section>
    </div>
  );
}
